﻿using System.Data;

class semana9
    {
        static void Main(string[] args)
        {
            int num = 0;
            int esPrimo = 1;
            Console.WriteLine("Ingrese un número entero positivo, con un máximo de 6 cifras.");
            try{
                num = Convert.ToInt32(Console.ReadLine());
                if(num < 1 || num > 999999){
                    Console.WriteLine("El número ingresado no es válido.");
                    return;
                } else {
                    if(num == 1){
                        esPrimo = 0;
                    } else if(num == 2) {
                        esPrimo = 1;
                    } else {
                        for (int i = 2; i <= Math.Sqrt(num); i++) {
                            if (num % i == 0) {
                                esPrimo = 0;
                                break;
                            }
                        }
                    }
                }

                if(esPrimo == 1) {
                    Console.WriteLine($"El número {num} es primo.");
                } else {
                    Console.WriteLine($"El número {num} no es primo.");
                }
            }catch{
                Console.WriteLine("El caracter ingresado no es valido, intentelo nuevamente.");
            }
        }
    }