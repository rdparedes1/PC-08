﻿namespace Parcial1_RubenParedes
{
    //Entradas: n1, n2 y n3
    //Proceso: las evaluaciones de números mayor o menor
    //Salida: Los mensajes que solicitan al usuario los numeros y el resultado final
    class parcial
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese el número 1");
            int n1 = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Ingrese el número 2");
            int n2 = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Ingrese el número 3");
            int n3 = Convert.ToInt16(Console.ReadLine());
            if((n1 > n2)&&(n3<n2)){
                if(n3<n2){
                    Console.WriteLine("El número mayor es: " + n1 + " y el menor " + n3);
                } else {
                    Console.WriteLine("El número mayor es: " + n1 + " y el menor " + n2);
                }
            }
            if((n2 > n1)&&(n1<n2)){
                if(n3<n1){
                    Console.WriteLine("El número mayor es: " + n2 + " y el menor " + n3);
                } else {
                    Console.WriteLine("El número mayor es: " + n2 + " y el menor " + n1);
                }
            }
            if((n3 > n2)&&(n1<n2)){
                if(n1<n2){
                    Console.WriteLine("El número mayor es: " + n3 + " y el menor " + n1);
                } else {
                    Console.WriteLine("El número mayor es: " + n3 + " y el menor " + n2);
                }
            }
        }
    }
}