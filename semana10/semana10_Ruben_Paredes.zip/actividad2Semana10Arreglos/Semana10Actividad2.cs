﻿class Semana10Actividad2 {
    static void Main(){
        int[] numeros = {0,0,0,0,0,0,0,0};
        int total = 0;
        for(int i = 0;i<8;i++){
            Console.WriteLine("Ingrese el número " + (i+1));
            try {
                numeros[i] = Convert.ToInt32(Console.ReadLine());
            } catch {
                Console.WriteLine("El caracter ingresado no es un número, intente nuevamente");
            }
        }
        Console.WriteLine("Los números ingresados son:");
        for(int a = 0; a<8; a++){
            Console.WriteLine(numeros[a]);
        }
        for(int b = 0; b<8; b++){
            total = total + numeros[b];
        }
        Console.WriteLine("La suma total de los números es: " + total);
        Console.WriteLine("El promedio de los números es: " + ((double)total/8));
    }
}