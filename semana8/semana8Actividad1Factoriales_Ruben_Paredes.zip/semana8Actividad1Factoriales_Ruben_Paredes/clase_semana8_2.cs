﻿class clase_semana8_2
{
   static void Main()
    {
        Boolean seguir = true;
        while(seguir) {
            try {
                Console.WriteLine("Ingrese un numero entero positivo.");
                int numero2 = Convert.ToInt32(Console.ReadLine());
                if(numero2 < 0) {
                    Console.WriteLine("El número debe ser entero positivo, intentelo nuevamente.");
                } else {
                    int resultado = CalcularFactorial(numero2);
                    Console.WriteLine("El factorial de " + numero2 + " es: " + resultado);
                    seguir = false;
                }
            } catch {
                Console.WriteLine("Ingrese un número valido, intente nuevamente.");
            }
        }
    }

    public static int CalcularFactorial(int numero){
        if(numero == 0){
            return 1;
        } else {
            int factorial = 1;
            for(int i = 1; i <= numero; i++){
                factorial *= i;
            }
            return factorial;
        }
    }
}